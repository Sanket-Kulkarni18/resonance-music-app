// ═══════════════════════════════════════════════════════════════════════════
// SyncPlay Server Unit Tests
// Run with: node test.js
// ═══════════════════════════════════════════════════════════════════════════

var passed = 0;
var failed = 0;

function assert(condition, message) {
  if (condition) {
    passed++;
    console.log('✓ ' + message);
  } else {
    failed++;
    console.log('✗ ' + message);
  }
}

function assertEqual(actual, expected, message) {
  if (actual === expected) {
    passed++;
    console.log('✓ ' + message);
  } else {
    failed++;
    console.log('✗ ' + message + ' (expected: ' + expected + ', got: ' + actual + ')');
  }
}

function assertNotNull(value, message) {
  if (value !== null && value !== undefined) {
    passed++;
    console.log('✓ ' + message);
  } else {
    failed++;
    console.log('✗ ' + message + ' (got null/undefined)');
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Mock Socket for testing
// ═══════════════════════════════════════════════════════════════════════════
function createMockSocket(id) {
  return {
    id: id,
    rooms: new Set(),
    events: {},
    emitted: [],
    join: function(roomId) {
      this.rooms.add(roomId);
    },
    leave: function(roomId) {
      this.rooms.delete(roomId);
    },
    emit: function(event, data) {
      this.emitted.push({ event: event, data: data });
    },
    on: function(event, handler) {
      this.events[event] = handler;
    },
    to: function() {
      return { emit: function() {} };
    }
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Server Module Tests
// ═══════════════════════════════════════════════════════════════════════════
console.log('\n═══════════════════════════════════════════════');
console.log('  SyncPlay Server Unit Tests');
console.log('═══════════════════════════════════════════════\n');

// Test: Module exports
console.log('--- Module Exports ---');
try {
  var server = require('./index.js');
  assertNotNull(server.createRoom, 'createRoom function exported');
  assertNotNull(server.getRoomState, 'getRoomState function exported');
  assertNotNull(server.generateRoomCode, 'generateRoomCode function exported');
  assertNotNull(server.rooms, 'rooms Map exported');
  assertNotNull(server.clientData, 'clientData Map exported');
} catch (e) {
  console.log('Note: Server module test skipped (server may be running)');
  console.log('Run tests before starting the server.\n');
}

// Test: generateRoomCode
console.log('\n--- generateRoomCode ---');
try {
  var server = require('./index.js');
  var code1 = server.generateRoomCode();
  assertEqual(code1.length, 4, 'Room code is 4 characters');
  assertEqual(code1, code1.toUpperCase(), 'Room code is uppercase');
  
  var code2 = server.generateRoomCode();
  assert(code1 !== code2 || true, 'Room codes are generated (may be same by chance)');
  
  // Check alphanumeric
  var isAlphanumeric = /^[A-Z0-9]+$/.test(code1);
  assert(isAlphanumeric, 'Room code is alphanumeric');
} catch (e) {}

// Test: createRoom
console.log('\n--- createRoom ---');
try {
  var server = require('./index.js');
  server.rooms.clear();
  
  var room = server.createRoom('socket-123', 'TestUser');
  assertNotNull(room, 'createRoom returns room object');
  assertEqual(room.id.length, 4, 'Room has 4-character ID');
  assertEqual(room.hostId, 'socket-123', 'Room has correct hostId');
  assertEqual(room.members.size, 1, 'Room has 1 member');
  
  var member = room.members.get('socket-123');
  assertEqual(member.name, 'TestUser', 'Member has correct name');
  assertEqual(member.isHost, true, 'Member is marked as host');
  
  assertEqual(room.playbackState.playing, false, 'Playback initially paused');
  assertEqual(room.playbackState.position, 0, 'Playback position is 0');
  assertEqual(room.playbackState.sequence, 0, 'Sequence starts at 0');
  
  assert(server.rooms.has(room.id), 'Room is stored in rooms Map');
  
  server.rooms.clear();
} catch (e) {}

// Test: getRoomState
console.log('\n--- getRoomState ---');
try {
  var server = require('./index.js');
  server.rooms.clear();
  
  var room = server.createRoom('socket-456', 'AnotherUser');
  var state = server.getRoomState(room);
  
  assertEqual(state.id, room.id, 'State has correct ID');
  assertEqual(state.hostId, 'socket-456', 'State has correct hostId');
  assert(Array.isArray(state.members), 'Members is an array');
  assertEqual(state.members.length, 1, 'Members array has 1 item');
  assertEqual(state.members[0].name, 'AnotherUser', 'Member name is correct');
  assertNotNull(state.playbackState, 'State has playbackState');
  
  server.rooms.clear();
} catch (e) {}

// Test: Room with multiple members
console.log('\n--- Multiple Members ---');
try {
  var server = require('./index.js');
  server.rooms.clear();
  
  var room = server.createRoom('host-1', 'Host');
  room.members.set('peer-1', { id: 'peer-1', name: 'Peer1', isHost: false });
  room.members.set('peer-2', { id: 'peer-2', name: 'Peer2', isHost: false });
  
  assertEqual(room.members.size, 3, 'Room has 3 members');
  
  var state = server.getRoomState(room);
  assertEqual(state.members.length, 3, 'State shows 3 members');
  assertEqual(state.totalCount, 3, 'Total count is 3');
  
  server.rooms.clear();
} catch (e) {}

// Test: Playback state updates
console.log('\n--- Playback State ---');
try {
  var server = require('./index.js');
  server.rooms.clear();
  
  var room = server.createRoom('host-2', 'Host');
  
  // Simulate play
  room.playbackState = {
    playing: true,
    position: 30.5,
    serverTimeAtPlay: Date.now(),
    sequence: 1
  };
  
  assertEqual(room.playbackState.playing, true, 'Playing state is true');
  assertEqual(room.playbackState.position, 30.5, 'Position is 30.5');
  assertEqual(room.playbackState.sequence, 1, 'Sequence is 1');
  
  // Simulate pause
  room.playbackState.playing = false;
  room.playbackState.sequence = 2;
  
  assertEqual(room.playbackState.playing, false, 'Playing state is false after pause');
  assertEqual(room.playbackState.sequence, 2, 'Sequence incremented to 2');
  
  server.rooms.clear();
} catch (e) {}

// Test: Host transfer
console.log('\n--- Host Transfer ---');
try {
  var server = require('./index.js');
  server.rooms.clear();
  
  var room = server.createRoom('host-original', 'OriginalHost');
  room.members.set('peer-new', { id: 'peer-new', name: 'NewHost', isHost: false });
  
  // Transfer host
  var oldHost = room.members.get(room.hostId);
  oldHost.isHost = false;
  
  room.hostId = 'peer-new';
  var newHost = room.members.get('peer-new');
  newHost.isHost = true;
  
  assertEqual(room.hostId, 'peer-new', 'hostId updated');
  assertEqual(oldHost.isHost, false, 'Old host demoted');
  assertEqual(newHost.isHost, true, 'New host promoted');
  
  server.rooms.clear();
} catch (e) {}

// Test: Ready members tracking
console.log('\n--- Ready Members ---');
try {
  var server = require('./index.js');
  server.rooms.clear();
  
  var room = server.createRoom('host-3', 'Host');
  room.members.set('peer-a', { id: 'peer-a', name: 'PeerA', isHost: false });
  room.members.set('peer-b', { id: 'peer-b', name: 'PeerB', isHost: false });
  
  // Mark members as ready
  room.readyMembers.add('host-3');
  assertEqual(room.readyMembers.size, 1, '1 member ready');
  
  room.readyMembers.add('peer-a');
  assertEqual(room.readyMembers.size, 2, '2 members ready');
  
  room.readyMembers.add('peer-b');
  assertEqual(room.readyMembers.size, 3, '3 members ready');
  
  var state = server.getRoomState(room);
  assertEqual(state.readyCount, 3, 'Ready count is 3');
  assertEqual(state.totalCount, 3, 'Total count is 3');
  
  // Reset ready on new track
  room.readyMembers = new Set();
  assertEqual(room.readyMembers.size, 0, 'Ready members reset');
  
  server.rooms.clear();
} catch (e) {}

// Test: Track loading
console.log('\n--- Track Loading ---');
try {
  var server = require('./index.js');
  server.rooms.clear();
  
  var room = server.createRoom('host-4', 'Host');
  
  // Load track
  room.currentTrack = { url: '/uploads/test.mp3', name: 'Test Song.mp3' };
  room.readyMembers = new Set();
  
  assertNotNull(room.currentTrack, 'Track is set');
  assertEqual(room.currentTrack.name, 'Test Song.mp3', 'Track name is correct');
  assertEqual(room.currentTrack.url, '/uploads/test.mp3', 'Track URL is correct');
  
  var state = server.getRoomState(room);
  assertNotNull(state.currentTrack, 'State includes currentTrack');
  
  server.rooms.clear();
} catch (e) {}

// Test: Client data tracking
console.log('\n--- Client Data ---');
try {
  var server = require('./index.js');
  server.clientData.clear();
  
  server.clientData.set('client-1', {
    roomId: null,
    rtt: 50,
    lastActivity: Date.now()
  });
  
  assert(server.clientData.has('client-1'), 'Client data stored');
  assertEqual(server.clientData.get('client-1').rtt, 50, 'RTT stored correctly');
  
  // Update RTT
  server.clientData.get('client-1').rtt = 30;
  assertEqual(server.clientData.get('client-1').rtt, 30, 'RTT updated');
  
  server.clientData.clear();
} catch (e) {}

// Test: Room cleanup
console.log('\n--- Room Cleanup ---');
try {
  var server = require('./index.js');
  server.rooms.clear();
  
  var room = server.createRoom('host-5', 'Host');
  var roomId = room.id;
  
  assert(server.rooms.has(roomId), 'Room exists');
  
  // Remove all members
  room.members.delete('host-5');
  
  if (room.members.size === 0) {
    server.rooms.delete(roomId);
  }
  
  assert(!server.rooms.has(roomId), 'Room deleted when empty');
  
  server.rooms.clear();
} catch (e) {}

// ═══════════════════════════════════════════════════════════════════════════
// Results
// ═══════════════════════════════════════════════════════════════════════════
console.log('\n═══════════════════════════════════════════════');
console.log('  Results: ' + passed + ' passed, ' + failed + ' failed');
console.log('═══════════════════════════════════════════════\n');

if (failed > 0) {
  process.exit(1);
}
